# Fun English — Project Brief (Claude Code Handoff)

**Product:** Fun English by Eduverse
**Curriculum:** DSKP Bahasa Inggeris Tahun 2 (KSSR Semakan 2017), CEFR A1 Low
**Founder/dev:** Solehan (Mosobimo) — solo build, following Eduverse's existing product pattern (Fun Math, Seronoknya Bahasa)

This file is the entry-point brief for Claude Code sessions building this product. Read this fully before generating code.

---

## 1. What This Project Is

A gamified English-learning web app for Malaysian Year 2 (Tahun 2) primary students, organised into 6 skill "Worlds" (Phonics, Listening, Speaking, Reading, Writing, Language Arts) rather than by textbook unit. Each World contains 3–4 modules, each module a self-contained mini-game. Full pedagogical spec: see `Fun-English-Module-Spec.md` in this repo (produced in prior planning pass — attach/reference it, don't regenerate from scratch).

**Architecture pattern to follow** (matches Ninja Math, Money Master, Seronok Sains):
- Self-contained single-file HTML5 apps per module where possible (canvas or DOM-based, Web Audio API for sound)
- Shared Firebase backend (Firestore) for student login and progress
- Mobile-first responsive design
- No build step required — plain HTML/CSS/JS, importable/testable by opening the file directly

---

## 2. Firebase Setup

- **Project:** `funenglish` (Firestore, region `asia-southeast1` — match existing Eduverse projects)
- **Auth model:** Shared student login — Name + Kelas + 4-digit PIN, SHA-256 hashed (same as Seronoknya Bahasa). No email/password accounts for pupils.

### Firestore schema

```
students/{studentId}
  name: string
  kelas: string
  pinHash: string (SHA-256)
  placement: {
    phonics: number (tier 1-3),
    listening: number,
    speaking: number,
    reading: number,
    writing: number
  }
  progress: {
    [moduleId]: {
      tier: number,
      stars: number (0-3),
      lastPlayed: timestamp
    }
  }
  badges: array<string>
  totalStars: number
```

- `moduleId` convention: `phonics-1`, `phonics-2`, `listening-1`, etc. — matches module numbering in the spec doc (Modules 1–18 + bonus zone items).
- Bonus Zone items: `bonus-chant`, `bonus-spotter`, `bonus-makerap`.

---

## 3. Module Build Order

Follow this sequence (see spec doc §6 for reasoning — reuse-driven, not difficulty-driven):

1. **Phonics World** (Modules 1–4) — build shared blend/segment engine first; Modules 2 & 3 reuse it in reverse.
2. **Listening World** (Modules 5–8) — reuses audio asset pipeline from Phonics.
3. **Reading World** (Modules 13–16) — reuses vocab/sentence banks from Listening.
4. **Writing World** (Modules 17–18) — reuses Sentence Builder drag mechanic from Reading.
5. **Speaking World** (Modules 9–12) — build last; requires mic recording/playback, most technically demanding.
6. **Bonus Zone** — build opportunistically once 2–3 Worlds are live.

**When starting a new session, always build one module (or one shared engine) at a time.** Don't attempt multi-module scaffolding in a single pass — matches prior Eduverse build pattern of iterative, testable single-file outputs.

---

## 4. Content Source of Truth

All vocabulary, grammar patterns, and Learning Standards references come from the DSKP Tahun 2 document (`Year_2.pdf`, KPM 2017) and the Unit Content Bank table in the spec doc (Units 5–9: Free Time, The Old House, Get Dressed, The Robot, At the Beach).

**Do not invent new vocabulary or grammar patterns outside this bank** without flagging it — content must stay curriculum-aligned since this is sold to parents/teachers on that basis.

---

## 5. Placement Quiz Logic

Per-strand, not overall. 5–8 questions per strand, game-format (not written test).

```
score 0-40%   → Tier 1 (foundational)
score 41-70%  → Tier 2 (practice)
score 71-100% → Tier 3 (challenge)
```

Store result in `students/{studentId}.placement.{strand}`. Reuse as default entry tier on return visits. Open design question (unresolved as of this brief): single combined placement flow vs. 6 separate quizzes triggered per-world on first entry — **default to per-world triggered quizzes** unless told otherwise, since it spreads onboarding friction across first-time-per-world sessions rather than front-loading it all.

---

## 6. Design/UX Notes

- Visual theme: not yet locked — prior products used arcade/night-sky (salespage) and warm kraft/sticker (PDF guide) styles. Propose a kid-friendly, bright, non-babyish theme suited to 7–8 year olds; confirm with founder before finalizing across all modules for consistency.
- Audio: model sentences need clear, neutral English pronunciation. TTS vs. real voice recording is an open question — flag before building audio-heavy modules (Listening, Speaking).
- Rewards: 1–3 stars per module based on accuracy. Badges awarded at strand-completion milestones. Class leaderboard should be teacher-toggleable, not on by default (KSSR emphasises collaborative over competitive learning at this stage).

---

## 7. Out of Scope For Now

- Real-time adaptive difficulty algorithms (tier system is manual/score-branch, not ML-driven)
- Speech recognition scoring for Speaking modules (self-comparison playback is sufficient for Y2)
- Cross-device sync beyond Firestore's default behavior
- Teacher/parent dashboard (may come later as a separate product layer, not part of this build)

---

## 8. Reference Files

- `Fun-English-Module-Spec.md` — full pedagogical + module spec (18 modules, 6 strands)
- `Year_2.pdf` — source DSKP curriculum document
