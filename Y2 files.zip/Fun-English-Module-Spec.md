# Fun English — Module Spec Document
**Eduverse by Mosobimo | KSSR Tahun 2 | CEFR A1 Low**

Concept inspired by LiteracyPlanet's skill-strand + adaptive-placement model, adapted to a single-file HTML5 game architecture matching Fun Math / Seronoknya Bahasa build patterns.

---

## 1. Product Overview

**Name:** Fun English (working title)
**Curriculum base:** DSKP Bahasa Inggeris Tahun 2 (KSSR Semakan 2017, aligned to CEFR)
**Target proficiency:** A1 Low by end of Year 2
**Structure:** 6 skill Strands ("Worlds"), 18 core modules + 1 bonus zone
**Source textbook mapping:** Superminds 1, Units 5–9

**Core design principle:** Modules are organised by *skill strand*, not by textbook unit. Each unit's vocabulary and grammar patterns are distributed across strands as content fuel, so a child moves through Phonics, Listening, Speaking, Reading, Writing, and Language Arts as parallel "worlds" rather than sequential unit blocks.

---

## 2. Unit Content Bank (source material for all strands)

| Unit | Topic | Theme | Key Grammar | Key Vocabulary |
|---|---|---|---|---|
| 5 | Free Time | Self, Family & Friends | I play football on Saturdays. / Do you watch TV at the weekend? | Days of week, healthy/unhealthy, badminton, sleep |
| 6 | The Old House | Stories | There's a monster. / Are there any rats? / How many cars are there? | Rooms of home, habitats, animals (goat, shark, penguin) |
| 7 | Get Dressed | Self, Family & Friends | Do you like this hat? / Olivia's wearing a red sweater. / Is he wearing...? | Clothes, cotton/leather/wool, cow, sheep |
| 8 | The Robot | Stories | I can/can't stand on one leg. / Can you swim? | Body parts, cheetah, kangaroo, run/jump/dance/crawl |
| 9 | At the Beach | Knowledge | Let's play the guitar. / Where's the blue book? / Where are the orange books? | Holiday activities, weather adjectives, sea/lake/forest |

This table is the single source of truth for vocab/grammar pulled into module content across all strands — avoids duplicating word lists per module.

---

## 3. Placement Quiz (Entry Diagnostic)

Matches LiteracyPlanet's "feels like a game, not a test" diagnostic. Not a real adaptive algorithm — a simple score-branch per strand.

**Format:** 5–8 questions per strand, presented as a mini-game (e.g., tap-the-picture, drag-and-drop), not a written test.

**Branch logic (per strand):**
- Score 0–40% → start at Tier 1 (foundational)
- Score 41–70% → start at Tier 2 (practice)
- Score 71–100% → skip to Tier 3 (challenge) or straight to strand's final module

**Why per-strand, not overall:** A child may be strong in Listening but weak in Writing (very common at this age/stage) — matching the DSKP's own design, where the four skills are assessed and reported separately (see Performance Standards Guides).

**Implementation note:** Store placement result per strand per student in Firestore (`students/{studentId}/placement`), reused to set default entry tier when the child returns to a world.

---

## 4. Strand & Module Breakdown

### 🔤 STRAND 1 — Phonics World
*Maps to Content Standard 3.1 (Learning to Read)*

| # | Module | Learning Standard | Game Mechanic | Tiering |
|---|---|---|---|---|
| 1 | Alphabet Hunt | 3.1.1 — Identify, recognise, name letters | Tap-the-letter / matching pairs across a scrolling scene | T1: uppercase only → T2: lower+upper → T3: timed |
| 2 | Sound Blender | 3.1.2, 3.1.3 — Beginning/medial/final sounds, blend phonemes | Drag letter tiles together to "blend" into a word; word forms + animates when correct | T1: CVC → T2: CCVC/CVCV → T3: CCV mixed |
| 3 | Sound Splitter | 3.1.4 — Segment phonemes | Reverse of Module 2: word shown, child taps/drags to split into sound tiles | Same CVC→CCVC→CCV progression |
| 4 | Phonics Table Challenge | Year 2 phonics table (ear/air/ure/er, ay/ou/ie/ea, oy/ir/ue/aw, etc.) | Sound-matching arcade game — audio plays, child picks the matching spelling pattern | T1–T3 by phoneme row (a–o per official table) |

**Design note:** Modules 2 & 3 should share one underlying "blend/segment" game engine (mirrors your reusable game-engine pivot from Seronoknya Bahasa) — same mechanic, direction reversed.

---

### 👂 STRAND 2 — Listening World
*Maps to Content Standard 1.2–1.3*

| # | Module | Learning Standard | Game Mechanic | Tiering |
|---|---|---|---|---|
| 5 | Listen & Match | 1.2.1 — Main idea of simple sentences | Audio plays a sentence; child picks matching image from 3–4 options | T1: 2 options → T2: 3 → T3: 4 + distractor audio |
| 6 | Detail Detective | 1.2.2 — Specific info/details | Audio plays; child answers a specific-detail question (who/what/where) via tap | Sentence length increases per tier |
| 7 | Story Ears | 1.2.3 — Very short narratives | Audio plays a 3–4 sentence mini-story; child sequences 3 picture cards in order | T1: 2-picture sequence → T3: 4-picture |
| 8 | Follow the Instruction | 1.2.4 — Classroom instructions | Audio gives an instruction ("Stand up," "Point to the door"); character on screen must act correctly, child taps yes/no if it's right | T1: single-step → T3: two-step chained instructions |

**Content source:** Draw sentence/instruction audio scripts from Unit 5–9 grammar bank (Section 2).

---

### 🗣️ STRAND 3 — Speaking World
*Maps to Content Standard 2.1–2.3*

| # | Module | Learning Standard | Game Mechanic | Tiering |
|---|---|---|---|---|
| 9 | About Me | 2.1.1, 2.1.2 — Give/ask personal info | Voice-recording prompt + sentence-builder (tap words in order); playback compares to model audio | T1: fill 1 blank → T3: full sentence construction |
| 10 | Can You...? | 2.1.4 — Ask about/express ability (Unit 8 grammar) | Two-character dialogue game: child picks correct question/answer pair from options | T1: yes/no picks → T3: free word-order build |
| 11 | Describe It | 2.1.5 — Describe objects | Object shown; child selects correct adjective(s) + noun to build a description, records themselves saying it | Vocabulary bank rotates through Units 6, 7, 9 |
| 12 | Introduce Yourself | 2.3.1 — Self-intro using fixed phrases | Guided recording task: child fills in name/likes into a fixed-phrase template, plays back "class introduction" | T1: name only → T3: name + 2 details |

**Note:** Speaking modules need audio recording capability — flag for tech scoping (mic permission handling, playback compare, no need for speech recognition scoring at this stage — self-comparison is enough for Y2).

---

### 📖 STRAND 4 — Reading World
*Maps to Content Standard 3.2–3.3*

| # | Module | Learning Standard | Game Mechanic | Tiering |
|---|---|---|---|---|
| 13 | Main Idea Match | 3.2.1 — Main idea of simple sentences | Read sentence, pick matching picture (silent reading version of Module 5) | T1–T3 by sentence complexity |
| 14 | Word Detective | 3.2.3 — Reread/ignore-unknown-word strategies | Short passage with 1 unknown/nonsense word; child answers comprehension Q without needing that word | T1: 1 unknown word → T3: 2–3 unknown words |
| 15 | Picture Dictionary Quest | 3.2.4 — Picture dictionary skills | Child sorts/categorises word cards into themed picture-dictionary "pages" (Unit topics as categories) | T1: 2 categories → T3: 5 categories (all units) |
| 16 | Reading for Fun | 3.3.1 — Read/enjoy simple print & digital games at sentence level | Light-touch: short interactive mini-story with choice branches (choose-your-own-adventure, sentence-level) | Not tiered — reward/relax module |

---

### ✍️ STRAND 5 — Writing World
*Maps to Content Standard 4.2–4.3*

| # | Module | Learning Standard | Game Mechanic | Tiering |
|---|---|---|---|---|
| 17 | Sentence Builder | 4.2.1–4.2.5, 4.3.3 — Guided sentence writing, conjunctions | Drag-word sentence assembly (word bank → sentence slots); auto-checks word order | T1: 3-word sentence → T3: conjunction-joined sentence |
| 18 | Spelling & Punctuation Sprint | 4.3.1, 4.3.2 — Capital letters/full stops, high-frequency spelling | Timed typing/tapping game: fix the sentence (add capital, add full stop, fix 1 spelling) | T1: one fix per sentence → T3: three fixes |

---

### 🎵 BONUS ZONE — Language Arts Corner
*Maps to Content Standard 5.1–5.3 — treated as reward content, not gated progression (per DSKP's own framing of Language Arts as an integrative, low-pressure strand)*

- **Chant & Rap Booth** — sing-along with on-screen lyrics + rhythm-tap scoring (5.1.1, 5.1.2)
- **Story Spotter** — name people/things/places in a short animated clip (5.2.1)
- **Make Your Own Rap** — mad-libs style: child picks words to fill a simple chant template, plays it back (5.3.1)

Unlocked by earning stars/badges across the 5 main strands — functions like LiteracyPlanet's "arcade" side content (e.g. Word Mania), not part of the placement/tier system.

---

## 5. Progress & Reward System (Firebase schema sketch)

Following your existing Firestore pattern (`asia-southeast1`, shared student login via Name + Kelas + 4-digit PIN):

```
students/{studentId}
  ├─ placement: { phonics: 2, listening: 1, speaking: 3, reading: 1, writing: 2 }
  ├─ progress: { moduleId: { tier: 2, stars: 3, lastPlayed: timestamp } }
  ├─ badges: [ "phonics-master", "chant-champion", ... ]
  └─ totalStars: number (unlocks Bonus Zone content)
```

- **Stars per module:** 1–3 stars based on accuracy, replicating LiteracyPlanet's points/badges/missions layer without needing a real-time adaptive engine.
- **Leaderboard (optional, class-level):** opt-in, shows star totals per Kelas — mirrors LiteracyPlanet's class leaderboard feature; consider making this teacher-toggleable given KSSR's collaborative-learning emphasis over competition for this age group.

---

## 6. Build Priority Recommendation

Given your single-founder capacity, suggested build order (highest content-reuse-per-effort first):

1. **Phonics World (Modules 1–4)** — shares one blend/segment engine, high standalone teaching value, easiest to demo for beta testers/resellers.
2. **Listening World (Modules 5–8)** — reuses audio-asset pipeline you'd build for Phonics.
3. **Reading World (Modules 13–16)** — shares sentence/vocab banks with Listening.
4. **Writing World (Modules 17–18)** — reuses Sentence Builder-style drag mechanic from Reading.
5. **Speaking World (Modules 9–12)** — most technically demanding (audio recording/playback); build last once core engine is proven.
6. **Bonus Zone** — build opportunistically alongside any strand once 2–3 core worlds are live, as a retention/engagement layer for beta.

---

## 7. Open Questions for Next Planning Pass

- Placement quiz: build as one combined intro flow, or 6 separate short quizzes triggered on first entry to each world?
- Audio asset production: TTS-generated vs. real voice recording for Malaysian-accent-neutral English model audio?
- Should Bonus Zone content count toward "completion" for reseller/parent-facing progress reports, or stay purely optional?
